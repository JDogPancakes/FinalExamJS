// JavaScript Document

class Person {//Class person takes 4 arguments
  constructor(name, age, gender, interests) {
    this.name = name;
    this.age = age;
    this.gender = gender;
    this.interests = interests;//Puts given variables into object
  }

  greeting() {//function displays message based on object's values
    console.log(`Hi! I'm ${this.name}`);
  };

  bye() {
    console.log(`${this.name} has left the building. Bye for now!`);//function displays message based on object's values
  };
}


let parth = new Person('Parth', 20, 'male', ['JavaScript', 'Java', 'PHP']);//Creates a new Person
let harmanpreet = new Person('Harmanpreet', 22, 'male', ['JavaScript', 'C#', 'Relational DataBase']);//Creates a new Person


class Teacher extends Person {//New teacher class is a parent to Person
  constructor(name, age, gender, interests, subject, grade) {//Has 6 values
    super(name, age, gender, interests);//4 of which come from a Person object
    // subject and grade are specific to Teacher
    this.subject = subject;
    this.grade = grade;
  }
}
let jaden = new Teacher('Jaden',19,'male',['Java, C#'],'Math',9);
